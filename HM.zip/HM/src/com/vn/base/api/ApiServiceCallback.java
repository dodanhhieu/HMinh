package com.vn.base.api;

import org.json.JSONObject;

public class ApiServiceCallback {

	/**
	 * 
	 */
	public void onStart(){
		
	}
	
	/**
	 * 
	 * @param msgError
	 */
	public void onError(String msgError){
		
	}
	
	/**
	 * 
	 * @param responeData
	 */
	public void onSucces(String responeData){
		
	}
	
	/**
	 * 
	 * @param responeJson
	 */
	public void onSucces(JSONObject responeJson){
		
	}
}
