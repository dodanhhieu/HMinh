package com.vn.hm.fragment;

import android.view.View;

import com.d3.base.BaseFragment;
import com.vn.hm.R;

public class LogoutFragment extends BaseFragment{

	@Override
	public int getlayout() {
		// TODO Auto-generated method stub
		return R.layout.activity_main;
	}

	@Override
	public void initView(View view) {
		// TODO Auto-generated method stub
		
	}

}
