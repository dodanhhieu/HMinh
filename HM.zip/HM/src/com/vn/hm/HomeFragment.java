package com.vn.hm;

import android.view.View;

import com.d3.base.BaseFragment;

public class HomeFragment extends BaseFragment{

	@Override
	public int getlayout() {
	
		return R.layout.activity_main;
	}

	@Override
	public void initView(View view) {
	
		
	}

	
}
